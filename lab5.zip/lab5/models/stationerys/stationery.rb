# frozen_string_literal: true

# The information about the good books
Stationery = Struct.new(:id, :name, :price, :quantity, keyword_init: true)
